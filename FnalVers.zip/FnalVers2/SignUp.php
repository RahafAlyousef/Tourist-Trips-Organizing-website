

<html>
<head>

<style> 
.a{
    margin: 10px;
    font-size: 20px;
    padding: 15px;
    text-align: center;
    color:#d63031;
    width: 500px;
    border-radius: 25px;
background-image: linear-gradient(to right, #b2bec3 0%, #dfe6e9 51%, #636e72 100%)

}
.t1{
position:absolute;
    top: 220;
    left: 430;}
.t2{
position:absolute;
    top: 280;
    left: 430;}
.t3{
position:absolute;
    top: 340;
    left: 430;}
.t4{
position:absolute;
    top: 400;
    left: 430;}
.t5{
position:absolute;
    top: 460;
    left: 430;}
	input[type=submit] {
    font-size: 14px;
    width: 20%;
    text-align: center;
    line-height: 40px;
    color:#2d3436;
    background-color:#dfe6e9;
	position:absolute;
    top: 540;
    left: 540;
	font-size: 20px;
}
body{
  background-image: url('a12.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style> 
</head>
<body>

<center>
<img src="lana2.png" alt="Login">
<form name="registration" action="" method="post">
  <input type="text" name="firstname" id="fname" class="a t1" placeholder="First Name" onchange="checkf()" required>
  <input type="text" name="Lname" id="lname" class="a t2" placeholder="Last Name" onchange="checkl()" required>
  <input type="email" name="email" id="email" class="a t3" placeholder="email" required>
<input type="password" name="password" id="password" class="a t4" placeholder="password" required>
<input type="text"  name="Phone" id="phoneNO" class="a t5" placeholder="Phone Number" onchange="checkp()" required>
<input type ="submit" value="Sign Up" name="sign"></a>
<br>


</form>
</center>

<script>
function checkf(){
   var input1=document.getElementById("fname").value;
  if(!(input1.match(/^[A-Za-z]+$/)))
      {
      alert('Please input alphabet characters only in first name');
	  clearf();
      }}
	function checkl(){  
var input2=document.getElementById("lname").value;
  if(!(input2.match(/^[A-Za-z]+$/)))
      {
      alert('Please input alphabet characters only in last name');
	  cleart();
      } }
	function checkp() { 

var data =document.getElementById("phoneNO").value;;
if(isNaN(data)){
  alert("Please input number only in Phone Number");
  clearp();
}else {
if (data.length != 10 ){
  alert("Please enter 10 number in Phone Number @_@");
  clearp();}
}
  }
   function clearf(){
	   	    <?php
$db = mysqli_connect("localhost", "root", "", "webproject");
$first_name = mysqli_real_escape_string($db, $_REQUEST['firstname']);
$last_name = mysqli_real_escape_string($db, $_REQUEST['Lname']);
$email = mysqli_real_escape_string($db, $_REQUEST['email']);
 $Password=mysqli_real_escape_string($db, $_REQUEST['password']);

$PhoneNO=mysqli_real_escape_string($db, $_REQUEST['Phone']);
$s="select * from customer";
$sql = "INSERT INTO customer (ID_CUST, EMAIL_CUST, F_NAME, L_NAME, PHONE_CUST, Password) VALUES ('$PhoneNO', '$email','$first_name','$last_name','$PhoneNO','$Password')";
if(array_key_exists('sign',$_POST)){
if(mysqli_query($db, $sql)){
    echo '<script>alert("Records added successfully.")</script>';
	header("Location: web4.html ");
}else{
	echo"";
	if(key_exists('sign',$_POST)){
	echo"Email or phone number is alreasy use";}

}}
mysqli_close($db);
?>
  		document.getElementById('fname').value = ''
  }
   function cleart(){
  		document.getElementById('lname').value = ''
  }
   function clearp(){
  		document.getElementById('phoneNO').value = ''
  }
</script>
</body>
<!--    echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);-->
</html>
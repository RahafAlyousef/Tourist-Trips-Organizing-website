<html>
<head>
<style>  
body{
  background-image: url('lana1.gif');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
h1{
position:absolute;
 top: 90;
 left:20;
font-weight:500;
font-size:81;
color:#fdcb6e;
background-color:rgba(0,0,0,0.10);
}
.a{
    margin: 10px;
    font-size: 20px;
    padding: 15px;
    text-align: center;
    text-transform: uppercase;
    color:#d63031;
    width: 220px;
    border-radius: 25px;
background-image: linear-gradient(to right, #DD5E89 0%, #F7BB97 51%, #DD5E89 100%)

}
.b{
position:absolute;
    top: 260;
    left: 530;}
</style>
</head>
<body>
<h1>Do you want to start your travel with us?</h1>
<button type="submit" onclick="document.location='login.php'" class="a b">Welcome</button>  
</body>
</html>
<html>
<head>
  <meta charset="utf-8">
  <title>Password Reset</title>
<style>

p.groove {border-style: groove;}
.navbar {
  overflow: hidden;
  background-color: #333;
}
</style>
<body style="background-color:lightgrey;">
<form action="" method="post" >
<br><br>
   <center>
   <br><br><br><br><br><br><br><br>
   
   <h3> Password Reset</h3>
      
        <p>  Enter your email.</p>
       

      <form class="Form" action="" method="post">
        <input type="text" name="Email" value=""><br><br>
        <input type="submit" value="Send" name="Give"> 
		 <input type="submit" value="Log in" >
		</form>
		
  </center>
  <?php
$db=new mysqli("localhost","root","","webproject");
$email=mysqli_real_escape_string($db, $_REQUEST['Email']);
$sql="select Password from customer where EMAIL_CUST='$email' ";
$result=$db->query($sql);
if(array_key_exists('Give',$_POST)){
if(mysqli_num_rows($result)>0)
  while($row = $result->fetch_assoc()) 
    echo " <center>Your password is  " . $row["Password"]."</center>" ;
   else 
  echo "<center>No email found</center>";
}
?>
</body>
</html>
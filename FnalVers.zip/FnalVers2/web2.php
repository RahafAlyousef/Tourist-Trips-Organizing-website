<html>
<head>
<style>
body {font-family: Arial, Helvetica, sans-serif;
background-color: lightgrey;}
form {border: 3px solid #f1f1f1;}
        
input[type=text], input[type=password],input[type=email] {
width: 100%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
box-sizing: border-box;}
        
.sub {
background-color:gray;
color: black;
padding: 14px 20px;
margin: 8px 0;
border: none;
cursor: pointer;
width: 100%;}
        
button:hover {
opacity: 0.8;}
        
.cancelbtn {
width: auto;
padding: 10px 18px;
background-color: black;
color:white;}
        
.imgcontainer {
text-align: center;
margin: 24px 0 12px 0;}
        
img.avatar {
width: 40%;
border-radius: 50%;}

.container {
padding: 16px;}
        
span.psw {
float: right;
padding-top: 16px;}
@media screen and (max-width: 300px) {
span.psw {
display: block;
float: none;}}
</style>
</head>
<body>
<form name="myForm" action="web4.html" method="post" required>
<div class="container input" >  
<label for="email">Email:</label><br>
<input type="email" id="emails" placeholder="Your Email" name="email" multiple required><br>
<label for="pwd">Password:</label><br>
<input type ="password" id="pwd" placeholder=" Your Password" name="pwd" minlength="8" value ="" required><br><br></div>
  <input class="sub" type="submit" value="Log in" >
  <input class="sub" type="submit" value="Sign up" onclick="document.location='SignUp.php'">
</form>
<div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn" onclick="document.location='web1.html'">Cancel</button>
    <span class="psw"> <a href="RetrievePass.php">Forgot Password?</a></span>
  </div>
</body></html>
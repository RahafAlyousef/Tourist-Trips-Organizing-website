var num;
function checkf(a){
 num=parseInt(a);
}
 function total(){
 var t=num+1000;
 alert("THE TOTAL PRICE = "+t);
 }
function validateForm() {
var p= registration.place.value;
if(p =="Default"){
alert("Please Choose your tourist place");}

var g= registration.guide.value;
if(g =="Default"){
alert("Please Choose your tourist guide");}}

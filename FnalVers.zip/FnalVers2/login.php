<html>
<head>
<script>
function validateForm() {
<?php
$db = mysqli_connect("localhost", "root", "", "trip");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $email = mysqli_real_escape_string($db,$_POST['email']);
      $pwd = mysqli_real_escape_string($db,$_POST['pwd']); 
      
      $sql = "SELECT ID_CUST FROM customer WHERE EMAIL_CUST = '$email' and Password = '$pwd'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         session_register("email");
         $_SESSION['login_user'] = $pwd;
         
         header("location: Web4.html");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
}</script>

<style>
body {font-family: Arial, Helvetica, sans-serif;
background-color: lightgrey;}
form {border: 3px solid #f1f1f1;}
        
input[type=text], input[type=password],input[type=email] {
width: 100%;
padding: 12px 20px;
margin: 8px 0;
display: inline-block;
border: 1px solid #ccc;
box-sizing: border-box;}
        
.sub {
background-color:gray;
color: black;
padding: 14px 20px;
margin: 8px 0;
border: none;
cursor: pointer;
width: 100%;}
        
button:hover {
opacity: 0.8;}
        
.cancelbtn {
width: auto;
padding: 10px 18px;
background-color: black;
color:white;}
        
.imgcontainer {
text-align: center;
margin: 24px 0 12px 0;}
        
img.avatar {
width: 40%;
border-radius: 50%;}

.container {
padding: 16px;}
        
span.psw {
float: right;
padding-top: 16px;}
@media screen and (max-width: 300px) {
span.psw {
display: block;
float: none;}}
</style>
</head>
<body>
<form name="myForm" action="web4.html" method="post" onsubmit="return a()" required>
<div class="container input" >  
<label for="email">Email:</label><br>
<input type="email" id="emails" placeholder="Your Email" name="email" multiple required><br>
<label for="pwd">Password:</label><br>
<input type ="password" id="pwd" placeholder=" Your Password" name="pwd" minlength="8" value ="" required><br><br></div>
  <input class="sub" type="submit" value="Log in" >
  <input class="sub" type="submit" value="Sign up" onclick="document.location='web3.html'">
</form>
<div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn" onclick="document.location='web1.html'">Cancel</button>
    <span class="psw"> <a href="RetrievePass.php">Forgot Password?</a></span>
  </div>
</body></html>
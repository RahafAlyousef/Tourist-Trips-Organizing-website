<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
       <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
    <style>
        body {
       background-color: lightgrey;
        }
       


input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
    background-color: royalblue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

p.groove {border-style: groove;}
.navbar {
  overflow: hidden;
  background-color: #333;}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;}

.dropdown {
  float: left;
  overflow: hidden;}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;}

.dropdown-content a:hover {
  background-color: #ddd;}

.dropdown:hover .dropdown-content {
  display: block;}

</style>
        
         </style>
</head>
<body>
  <div class="navbar">
    <a href="web4.html">Home</a>
   
     <div class="dropdown">
      <button class="dropbtn">profile 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="chang_password.html">Change password</a>
        <a href="ChangeEmail.php">Change Email</a>
		<a href="ChnagePhoneNo.php">Change Phone Number</a>
		<a href="ChangeFName.php">Change First Name</a> 
		<a href="ChangeLName.php">Change Last Name</a>
      </div>
    </div>
     <a href="web7.html">Booked trips</a>
      <a href="Contact.html">Contact Us</a>
       <a href="web1.php">Logout</a>
  </div>
<br><br>

    <h1>Change Password</h1>

<form method="post" action="">

<label for="newPassword">New Password:</label>
<input type="password" id="newPassword" name="newPassword" title="New password" />

<label for="confirmPassword">Confirm Password:</label>
<input type="password" id="confirmPassword" name="confirmPassword" title="Confirm new password" />

<label for="token">Current Password :</label>
<input type="text" id="token" name="token" title="Password Token" />

<p class="form-actions">
<input type="submit" value="Change Password" title="Change password" onclick="getPass()" />
</p>

</form>

</body>



 <script type="text/javascript">

<!--newPassword = Request["newPassword"];
confirmPassword = Request["confirmPassword"];
token = Request["token"];
if( Ispost){
    // input testing is ommitted here to save space
    retunValue = ResetPassword(token, newPassword);
}-->
function getPass(){
<?php
$db=new mysqli("localhost","root","","webproject");
$NWpassword=$_POST["newPassword"];
$CurrentPass=$_POST["token"];
$sql="select Password from customer where Password='$CurrentPass' ";
$result=$db->query($sql);
if(mysqli_num_rows($result)>0){
	$sql="update customer set password= '$NWpassword' where Password='$CurrentPass' ";
if($db->query($sql))
echo "<h4>Password has been changed</h4>";
else
echo "<h4>Invalid current password</h4>";
}
else
"<h4>Invalid curt password</h4>";
mysqli_close($db);?>}
</script>
</html>

